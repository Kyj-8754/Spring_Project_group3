package com.codingbox.group3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingbox.group3.domain.Menu;
import com.codingbox.group3.domain.Store;
import com.codingbox.group3.dto.MemberForm;
import com.codingbox.group3.dto.StoreDTO;
import com.codingbox.group3.em.Parking;
import com.codingbox.group3.em.Time;
import com.codingbox.group3.service.StoreService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class StoreController {

    private final StoreService storeService;

    @GetMapping("/store/write")
    public String writeStoreForm(Model model) {
        model.addAttribute("storeDTO", new StoreDTO());
        return "writeStore";
    }

    
    @PostMapping("/store/write")
    public String writeStore(@Valid StoreDTO storeDTO, BindingResult result) {
        Store store = new Store();
        store.setName(storeDTO.getName());
        store.setPhone(storeDTO.getPhone());
        store.setKeyword(storeDTO.getKeyword());
       // store.setParking(Parking.valueOf(storeDTO.getParking())); // Parking 열거형으로 변환
        //store.setTime(Time.valueOf(storeDTO.getTime())); // Time 열거형으로 변환
        store.setAddr(storeDTO.getAddr());

        storeService.saveStore(store);
        return "redirect:/";
    }

    //@GetMapping("/store/view/{id}")
    public String viewStore1(@PathVariable Long id, Model model) {
        Store store = storeService.findById(id);
        model.addAttribute("store", store);
        return "storedetail";
        
    }
    @GetMapping("/store/view/{id}")
    public String viewStore(@PathVariable Long id, Model model) {
        Store store = storeService.findById(id);
        model.addAttribute("store", store);
        return "storedetail";
    
    }
    
}