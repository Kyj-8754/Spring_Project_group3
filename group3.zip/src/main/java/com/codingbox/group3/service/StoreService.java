package com.codingbox.group3.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.codingbox.group3.domain.Store;
import com.codingbox.group3.dto.StoreDTO;
import com.codingbox.group3.em.Parking;
import com.codingbox.group3.em.Time;
import com.codingbox.group3.repository.StoreRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class StoreService {

    private final StoreRepository storeRepository;

    @Transactional
    public void saveStore(Store store) {
        storeRepository.saveStore(store);
    }

    @Transactional
    public Store findById(Long id) {
    	System.out.println("id : " + id);
        return storeRepository.findById(id);
    }

    @Transactional
    public void updateStore(Long storeId, StoreDTO storeDTO) {
        Store store = storeRepository.findone(storeId);
        store.setName(storeDTO.getName());
        store.setPhone(storeDTO.getPhone());
        store.setKeyword(storeDTO.getKeyword());
        store.setParking(Parking.valueOf(storeDTO.getParking())); // Parking 열거형으로 변환
        store.setTime(Time.valueOf(storeDTO.getTime())); // Time 열거형으로 변환
        store.setAddr(storeDTO.getAddr());
    }

}