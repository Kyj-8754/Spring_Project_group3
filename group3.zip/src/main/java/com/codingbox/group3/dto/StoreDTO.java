package com.codingbox.group3.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class StoreDTO {
	
	private Long id;
	
	private String name;
	private String phone;
	private String keyword;
	private String parking;
	private String time;
	private String menu;
	private String addr;
}
