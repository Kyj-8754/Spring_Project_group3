package com.codingbox.group3.em;

public enum ReservationStatus {
	COMPLETE, ING, CANCEL;
}
