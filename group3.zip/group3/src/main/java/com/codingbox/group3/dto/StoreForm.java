package com.codingbox.group3.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class StoreForm {
	private String storeName;
	private String storeAddr;
	private String storePhone;
	private String storeRoadAddr;
	
}
