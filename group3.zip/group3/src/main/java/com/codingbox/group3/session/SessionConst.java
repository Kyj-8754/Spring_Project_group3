package com.codingbox.group3.session;

public class SessionConst {

  public static final String LOGIN_MEMBER = "loginMember";
}
