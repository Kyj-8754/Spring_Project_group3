package com.codingbox.group3.em;

public enum Parking {

	주차가능, 주차불가능
}
