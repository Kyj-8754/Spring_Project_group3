package com.codingbox.group3.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class PageController {

	 @GetMapping("/reservation_list")
	    public String ReservationList(Model model) {
	       

	        return "reservation_list"; 
	    }
	 
	 @GetMapping("/revise")
	    public String Revise(Model model) {
	       

	        return "revise"; 
	    }
	 
	 @GetMapping("/reviewpage")
	    public String ReviewList(Model model) {
	       

	        return "reviewpage"; 
	    }
	}

